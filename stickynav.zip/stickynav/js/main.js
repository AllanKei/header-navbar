var slideIndex,slides,dots,content;
function initGallery() {
  slideIndex=0;
  slides=document.getElementsByClassName("imageholder");
  slides[slideIndex], style,opacity=1;

}